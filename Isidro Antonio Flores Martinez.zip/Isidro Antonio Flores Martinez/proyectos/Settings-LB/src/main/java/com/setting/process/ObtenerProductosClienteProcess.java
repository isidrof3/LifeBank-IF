package com.setting.process;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.setting.pojo.entity.Cuenta;
import com.setting.pojo.entity.Prestamo;
import com.setting.pojo.entity.Tarjeta;
import com.setting.pojo.producto.Accounts;
import com.setting.pojo.producto.CreditCard;
import com.setting.pojo.producto.Loan;
import com.setting.pojo.producto.Personal;
import com.setting.pojo.producto.ProductoResponse;
import com.setting.pojo.producto.ProductosClientesRequest;
import com.setting.repository.CuentaRepository;
import com.setting.repository.PrestamoRepository;
import com.setting.repository.TarjetaRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ObtenerProductosClienteProcess {

	private CuentaRepository cuentaRepository;
	private TarjetaRepository tarjetaRepository;
	private PrestamoRepository prestamoRepository;
	
	public ObtenerProductosClienteProcess(CuentaRepository cuentaRepository, TarjetaRepository tarjetaRepository,
			PrestamoRepository prestamoRepository) {
		this.cuentaRepository = cuentaRepository;
		this.prestamoRepository = prestamoRepository;
		this.tarjetaRepository = tarjetaRepository;
		
	}
	
	public ProductoResponse productosXCliente(ProductosClientesRequest request){
		ProductoResponse response;

		List<Cuenta> listCuenta;
		List<Tarjeta> listTarjeta;
		List<Prestamo> listPrestamo;
		List<CreditCard> listCreditCard;
		List<Personal> listPersonal;
		List<Loan> listLoan;
		try {
		
			response = new ProductoResponse();
			listCuenta = new ArrayList<Cuenta>();
			listCreditCard = new ArrayList<CreditCard>();
			listPersonal = new ArrayList<Personal>();
			listLoan = new ArrayList<Loan>();
			
			//se obtiene las cuentas del cliente
			listCuenta = cuentaRepository.obtenerCuentas(request.getCliente());
			
			for (Cuenta cuenta: listCuenta) {
				Accounts account = new Accounts();
				Loan loan = new Loan();
				loan.setId(cuenta.getNumCuenta());
				loan.setName(cuenta.getCodigoProducto());
				listLoan.add(loan);
				
				//se obtiene los productos tarjetas
				listTarjeta = tarjetaRepository.obtenerTarjetas(request.getCliente(), cuenta.getNumCuenta());
				for(Tarjeta tarjeta:listTarjeta) {
					CreditCard creditCard = new CreditCard();
					creditCard.setId(tarjeta.getNumTarjeta());
					creditCard.setName(tarjeta.getCodigoProducto());
					listCreditCard.add(creditCard);
				}
				
				//se obtiene los productos prestamo
				listPrestamo = prestamoRepository.obtenerPrestamos(request.getCliente(), cuenta.getNumCuenta());
				
				for(Prestamo prestamo: listPrestamo) {
					Personal personal = new Personal();
					personal.setId(prestamo.getCodigo());
					personal.setName(prestamo.getCodigoProducto());
					listPersonal.add(personal);
				}
				
				account.setCreditCard(listCreditCard);
				account.setPersonal(listPersonal);
				account.setLoan(listLoan);
				response.setAccounts(account);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			response = null;
		}
		
		return response;
	}
}
