package com.setting.pojo.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity(name = "cta_cuenta")
@Data
public class Cuenta {
	@Id
	@Column(name = "cta_cli_codigo")		
	private String id;		

	@Column(name = "cta_num_cuenta")
	private String numCuenta;
	
	@Column(name = "cta_tipo_cuenta")
	private String tipoCuenta;
	
	@Column(name = "cta_fecha_creacion")
	private Date fechaCreacion;
	
	@Column(name = "cta_creado_por")
	private String creadoPor;
	
	@Column(name = "cta_fecha_modificacion")
	private Date fechaModificacion;
	
	@Column(name = "cta_modificado_por")
	private String modificadoPor;
	
	@Column(name = "cta_pro_codigo")
	private String codigoProducto;	
}
