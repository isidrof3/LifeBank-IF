package com.lifebank.process.usuario;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.lifebank.pojo.autenticacion.AutenticacionRequest;
import com.lifebank.pojo.usuario.UsuarioResponse;
import com.lifebank.pojo.usuario.UsuarioxIDRequest;
import com.lifebank.utility.RestClient;
import com.lifebank.utility.ServiceUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ObtenerUsuarioProcess {
	
	private Environment env;
	private RestClient restClient;
	
	public ObtenerUsuarioProcess(Environment env, RestClient restClient) {
		this.env = env;
		this.restClient = restClient;	
	}
	
		public UsuarioResponse obtenerUsuario(String usuario, String password) throws Exception{
			UsuarioResponse usuarioResponse = new UsuarioResponse();
			AutenticacionRequest request;
			try {
				request = new AutenticacionRequest();
				request.setUsuario(usuario);
				request.setPassword(password);
				String tpmUrl = env.getProperty("service.setting.obtenerUsuario.url");
				log.error("Request usuario: " + request);
				usuarioResponse = restClient.call(tpmUrl, HttpMethod.POST, null, request, new ParameterizedTypeReference<UsuarioResponse>() {});
				log.error("Response DbParameter: " + ServiceUtils.objToString(usuarioResponse));
			} catch (Exception e) {
				// TODO: handle exception
				log.error(e.getMessage());
				throw e;
			}
			
			return usuarioResponse;
		}
		
		public UsuarioResponse obtenerUsuarioxID(String id) throws Exception{
			UsuarioResponse usuarioResponse = new UsuarioResponse();
			UsuarioxIDRequest request;
			try {
				request = new UsuarioxIDRequest();
				String tpmUrl = env.getProperty("service.setting.obtenerUsuarioID.url");
				request.setId(id);
				log.error("Request usuario: " + request);
				usuarioResponse = restClient.call(tpmUrl, HttpMethod.POST, null, request, new ParameterizedTypeReference<UsuarioResponse>() {});
				log.error("Response DbParameter: " + ServiceUtils.objToString(usuarioResponse));
			} catch (Exception e) {
				// TODO: handle exception
				log.error(e.getMessage());
				throw e;
			}
			
			return usuarioResponse;
		}
	
	
}
