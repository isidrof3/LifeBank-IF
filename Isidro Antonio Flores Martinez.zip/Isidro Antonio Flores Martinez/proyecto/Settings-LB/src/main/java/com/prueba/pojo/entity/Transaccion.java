package com.prueba.pojo.entity;

public class Transaccion {

}
