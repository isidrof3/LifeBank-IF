CREATE TABLE lifebank.lb_banco (
	id_banco varchar NULL,
	nombre varchar NULL
)
WITH (
	OIDS=FALSE
) ;


CREATE TABLE lifebank.lb_cuenta (
	id_cuenta varchar NULL,
	id_cliente varchar NULL,
	num_cuenta varchar NULL,
	tipo_cuenta varchar NULL
);

CREATE TABLE lifebank.lb_tarjeta (
	id_tarjeta varchar NULL,
	id_cliente varchar NULL,
	num_tarjeta varchar NULL,
	tipo_tarjeta varchar NULL
);

CREATE TABLE lifebank.lb_transaccion (
	id_transaccion varchar NULL,
	id_cliente varchar NULL,
	num_autorizacion varchar NULL,
	fecha varchar NULL,
	tipo varchar NULL,
	monto varchar NULL
);

CREATE TABLE lifebank.lb_cliente (
	id_cliente varchar NULL,
	nombre varchar NULL,
	apellido varchar NULL,
	telefono varchar NULL,
	saldo varchar NULL,
	correo_electronico varchar NULL
);

CREATE TABLE lifebank.lb_usuario (
	usuario varchar NULL,
	"password" varchar NULL,
	id_cliente varchar NULL
);

