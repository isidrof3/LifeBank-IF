package com.setting.process;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.setting.pojo.entity.Usuario;
import com.setting.pojo.producto.ProductoResponse;
import com.setting.pojo.producto.ProductosClientesRequest;
import com.setting.pojo.response.WrapperResponse;
import com.setting.pojo.transacciones.TransaccionesProdcutosResponse;
import com.setting.pojo.transacciones.TransaccionesRequest;
import com.setting.pojo.usuario.ActualizaIntentosRequest;
import com.setting.pojo.usuario.ActualizarEstadoRequest;
import com.setting.pojo.usuario.ObtenerxIdRequest;
import com.setting.pojo.usuario.UsuarioRequest;
import com.setting.pojo.usuariocliente.request.UsuarioClienteRequest;
import com.setting.utility.SettingsProperties.error;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
public class JsonProcess
{
	private Environment env;
	private ManejarUsuarioClienteProcess manejarUsuarioClienteProcess;
	private UsuarioProcess usuarioProcess;
	private ActualizarIntentosFallidosProcess actualizaIntentosProcess;
	private ActualizarEstadoProcess actualizarEstadoProcess;
	private ObtenerProductosClienteProcess obtenerProductosClienteProcess;
	private TransaccionesxProductoProcess transaccionesxProductoProcess;

	public JsonProcess(Environment env, ManejarUsuarioClienteProcess manejarUsuarioClienteProcess, UsuarioProcess usuarioProcess,
			ActualizarIntentosFallidosProcess actualizaIntentosProcess, ObtenerProductosClienteProcess obtenerProductosClienteProcess,
			TransaccionesxProductoProcess transaccionesxProductoProcess)
	{
		this.env = env;
		this.manejarUsuarioClienteProcess = manejarUsuarioClienteProcess;
		this.usuarioProcess = usuarioProcess;
		this.actualizaIntentosProcess = actualizaIntentosProcess;
		this.obtenerProductosClienteProcess = obtenerProductosClienteProcess;
		this.transaccionesxProductoProcess = transaccionesxProductoProcess;
	}
	
public WrapperResponse<Boolean> usuarioCliente(UsuarioClienteRequest request) {
		
		Boolean resultado;
		WrapperResponse<Boolean> response = new WrapperResponse<>();
		
		try {
			resultado = false;
			resultado = manejarUsuarioClienteProcess.agregarClienteUsuario(request);
			
			response.getHeader().setCode(env.getProperty("service.status.success.code"));
			response.getHeader().setMessage(env.getProperty("service.status.success.message"));
			response.setBody(resultado);
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error("Error - JsonProcess: usuarioCliente ==> " + e.getMessage());
			response.getHeader().setCode(env.getProperty("service.status.error.code"));
			response.getHeader().setMessage(e.getMessage());
		}
		
		return response;
	}

public WrapperResponse<Usuario> obtenerUsuario(UsuarioRequest request) {
	
	WrapperResponse<Usuario> response = new WrapperResponse<>();
	Usuario usuario;
	try {
		usuario = usuarioProcess.obtenerUsuario(request);
		
		
		response.setBody(usuario);
		
		if (usuario == null) {
			response.getHeader().setCode(error.getUsuarioNoExisteCode());
			response.getHeader().setMessage(error.getUsuarioNoExisteMsg());
		} else {
			response.getHeader().setCode(env.getProperty("service.status.success.code"));
			response.getHeader().setMessage(env.getProperty("service.status.success.message"));
		}
		
	} catch (Exception e) {
		// TODO: handle exception
		log.error("Error - JsonProcess: usuario ==> " + e.getMessage());
		response.getHeader().setCode(env.getProperty("service.status.error.code"));
		response.getHeader().setMessage(e.getMessage());
		}
	
	return response;
	}

public WrapperResponse<Usuario> actualizarIntentos(ActualizaIntentosRequest request) {
	
	WrapperResponse<Usuario> response = new WrapperResponse<>();
	Usuario usuario;
	try {
		usuario = actualizaIntentosProcess.actualizarIntentosFallidos(request);
		
		response.setBody(usuario);
		
		response.getHeader().setCode(env.getProperty("service.status.success.code"));
		response.getHeader().setMessage(env.getProperty("service.status.success.message"));
		
	} catch (Exception e) {
		// TODO: handle exception
		log.error("Error - JsonProcess: usuario ==> " + e.getMessage());
		response.getHeader().setCode(env.getProperty("service.status.error.code"));
		response.getHeader().setMessage(e.getMessage());
	}
	
	return response;
}

public WrapperResponse<Usuario> obtenerUsuarioxID(ObtenerxIdRequest request) {
	
	WrapperResponse<Usuario> response = new WrapperResponse<>();
	Usuario usuario;
	try {
		usuario = usuarioProcess.obtenerUsuarioXID(request);
		
		response.setBody(usuario);
		
		response.getHeader().setCode(env.getProperty("service.status.success.code"));
		response.getHeader().setMessage(env.getProperty("service.status.success.message"));
		
	} catch (Exception e) {
		// TODO: handle exception
		log.error("Error - JsonProcess: usuario ==> " + e.getMessage());
		response.getHeader().setCode(env.getProperty("service.status.error.code"));
		response.getHeader().setMessage(e.getMessage());
	}
	
	return response;
}

public WrapperResponse<Usuario> ActualizaEstado(ActualizarEstadoRequest request) {
	
	WrapperResponse<Usuario> response = new WrapperResponse<>();
	Usuario usuario;
	try {
		usuario = actualizarEstadoProcess.actualizarEstado(request);
		
		response.setBody(usuario);
		
		response.getHeader().setCode(env.getProperty("service.status.success.code"));
		response.getHeader().setMessage(env.getProperty("service.status.success.message"));
		
	} catch (Exception e) {
		// TODO: handle exception
		log.error("Error - JsonProcess: usuario ==> " + e.getMessage());
		response.getHeader().setCode(env.getProperty("service.status.error.code"));
		response.getHeader().setMessage(e.getMessage());
	}
	
	return response;
}

public WrapperResponse<ProductoResponse> ProductosXCliente(ProductosClientesRequest request) {
	
	WrapperResponse<ProductoResponse> response = new WrapperResponse<>();
	ProductoResponse productoResponse;
	try {
		productoResponse = obtenerProductosClienteProcess.productosXCliente(request);
		
		response.setBody(productoResponse);
		
		response.getHeader().setCode(env.getProperty("service.status.success.code"));
		response.getHeader().setMessage(env.getProperty("service.status.success.message"));
		
	} catch (Exception e) {
		// TODO: handle exception
		log.error("Error - JsonProcess: usuario ==> " + e.getMessage());
		response.getHeader().setCode(env.getProperty("service.status.error.code"));
		response.getHeader().setMessage(e.getMessage());
	}
	
	return response;
}

public WrapperResponse<TransaccionesProdcutosResponse> TransaccionesProductos(TransaccionesRequest request) {
	
	WrapperResponse<TransaccionesProdcutosResponse> response = new WrapperResponse<>();
	TransaccionesProdcutosResponse transaccionesProdcutosResponse;
	try {
		transaccionesProdcutosResponse = transaccionesxProductoProcess.productosXCliente(request);
		
		response.setBody(transaccionesProdcutosResponse);
		
		response.getHeader().setCode(env.getProperty("service.status.success.code"));
		response.getHeader().setMessage(env.getProperty("service.status.success.message"));
		
	} catch (Exception e) {
		// TODO: handle exception
		log.error("Error - JsonProcess: usuario ==> " + e.getMessage());
		response.getHeader().setCode(env.getProperty("service.status.error.code"));
		response.getHeader().setMessage(e.getMessage());
	}
	
	return response;
}



}
