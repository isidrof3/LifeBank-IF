package com.setting.pojo.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity(name = "usr_usuario")
@Data
public class Usuario {
		@Id
		@Column(name = "usr_usuario")		
		private String usuario	;		

		@Column(name = "usr_password")		
		private String password	;	
		
		@Column(name = "usr_cli_codigo")
		private String cliCodigo;
		
		@Column(name = "usr_fecha_creacion")
		private Date fechaCreacion;
		
		@Column(name = "usr_creado_por")
		private String creadoPor;
		
		@Column(name = "usr_fecha_modificacion")
		private Date fechaModificacion;
		
		@Column(name = "usr_modificado_por")
		private String modificadoPor;
		
		@Column(name = "usr_intentos_fallidos")
		private Integer intentosFallidos;
		
		@Column(name = "usr_estado")
		private Integer estado;		

}
