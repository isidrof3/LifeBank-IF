package com.setting.pojo.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity(name = "pro_producto")
@Data
public class Producto {
	@Id
	@Column(name = "pro_codigo")		
	private Integer id;		

	@Column(name = "pro_nombre")
	private String nombre;
	
	@Column(name = "pro_descripcion")
	private String descripcion;
	
	@Column(name = "pro_fecha_creacion")
	private Date fechaCreacion;
	
	@Column(name = "pro_creado_por")
	private String creadoPor;
	
	@Column(name = "pro_fecha_modificacion")
	private Date fechaModificacion;
	
	@Column(name = "pro_modificado_por")
	private String modificadoPor;
}
