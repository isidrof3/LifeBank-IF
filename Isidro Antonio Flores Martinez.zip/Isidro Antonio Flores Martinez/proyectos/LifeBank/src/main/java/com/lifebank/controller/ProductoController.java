package com.lifebank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lifebank.pojo.producto.ProductosClientesResponse;
import com.lifebank.process.producto.ProductosClienteProcess;

@RestController
//@RequestMapping("/producto")
public class ProductoController {
private ProductosClienteProcess proc;
	
	@Autowired
	public ProductoController(ProductosClienteProcess proc)
	{
		this.proc = proc;
	}
	
	 @GetMapping(value = "/producto/{cliente}")
	    public @ResponseBody ProductosClientesResponse getProductosXCliente(@PathVariable String cliente) {
		 ProductosClientesResponse response;
	        try {
	        	response = new ProductosClientesResponse();
				response =  proc.productosXCliente(cliente);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				response = null;
			}
	        return response;
	    }
	
}

