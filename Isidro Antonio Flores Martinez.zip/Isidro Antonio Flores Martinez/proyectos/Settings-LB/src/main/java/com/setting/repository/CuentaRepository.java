package com.setting.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.setting.pojo.entity.Cuenta;

public interface CuentaRepository extends CrudRepository<Cuenta, String>{
	
	@Query(value="select * " + 
			"	from cta_cuenta " + 
			"	where cta_cli_codigo = :cliente ;", nativeQuery = true)
	public List<Cuenta> obtenerCuentas(@Param("cliente") String cliente);
	
	@Query(value="select *  " + 
			"		from cta_cuenta " + 
			"		where cta_num_cuenta = :cuenta ;", nativeQuery = true)
	public Cuenta obtenerCuenta(@Param("cuenta") String cuenta);
	
	@Query(value="select *  " + 
			"		from cta_cuenta " + 
			"		where cta_num_cuenta = :cuenta ;", nativeQuery = true)
	public Cuenta obtener(@Param("cuenta") String cuenta);
	
}
