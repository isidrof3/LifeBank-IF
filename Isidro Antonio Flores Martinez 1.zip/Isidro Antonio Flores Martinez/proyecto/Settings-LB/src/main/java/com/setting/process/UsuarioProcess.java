package com.setting.process;

import org.springframework.stereotype.Service;

import com.setting.pojo.entity.Usuario;
import com.setting.pojo.usuario.ObtenerxIdRequest;
import com.setting.pojo.usuario.UsuarioRequest;
import com.setting.repository.UsuarioRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UsuarioProcess {

	private UsuarioRepository usuarioRepository;
	
	public UsuarioProcess(UsuarioRepository usuarioRepository){
		this.usuarioRepository = usuarioRepository;
	}
	
	public Boolean agregarUsuario(Usuario usuario) throws Exception {
		Boolean resultado;
		Usuario response;
		try {
			resultado = false;
			//agregando usuario a la base de datos
			response = usuarioRepository.save(usuario);
			
			if(response != null) {
				resultado = true;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			resultado = false;
		}
		
		return resultado;
	}
	
	public Usuario obtenerUsuario(UsuarioRequest request) {
		Usuario usuario;
		try {
			usuario = new Usuario();
			//obteneniendo usuario
			usuario = usuarioRepository.obtenerUsuario(request.getUsuario(), request.getPassword());
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			usuario = null;
		}
		
		return usuario;
	}
	
	public Usuario obtenerUsuarioXID(ObtenerxIdRequest request) {
		Usuario usuario;
		try {
			usuario = new Usuario();
			//obteneniendo usuario
			usuario = usuarioRepository.obtenerUsuarioporID(request.getUsuario());
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			usuario = null;
		}
		
		return usuario;
	}
}
