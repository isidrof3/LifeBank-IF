package com.setting.repository;

import org.springframework.data.repository.CrudRepository;
import com.setting.pojo.entity.Cliente;

public interface ClienteRepository extends CrudRepository<Cliente, String>{

//	@Query("select w "
//			+ " from aes_aerolineas_star w where (w.endDate is null and :today >= w.beginDate) or (w.endDate is not null and :today >= w.beginDate and :today <= w.endDate)")
//	public List<AirLines> getListAirLines(@Param("today") Date today);
	
}
