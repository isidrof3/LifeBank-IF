package com.lifebank.process;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.lifebank.pojo.usuario.UsuarioResponse;
import com.lifebank.utility.JWT;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class GenerarTokenProcess {

	private Environment env;
	
	public GenerarTokenProcess(Environment env) {
		this.env = env;
	}
	
	public String generarJWT(UsuarioResponse usuarioResponse, String ipAddress) {
		String sch = null;
		Map<String, Object> mapJWT = new HashMap<String, Object>();
		 
		try {
			LocalDateTime now = LocalDateTime.now();
			now = now.plusMinutes(Long.parseLong(env.getProperty("service.jwt.claim.minutosNoRenovables")));
			
			mapJWT.put("idCliente", usuarioResponse.getBody().getCliCodigo());
			mapJWT.put("ipAddress", ipAddress);
			mapJWT.put("expirationDateTime", now);
			
			
			JWT jwt = new JWT(mapJWT,
					env.getProperty("service.jwt.claim.secret"),
					env.getProperty("service.jwt.claim.subject"),
					env.getProperty("service.jwt.claim.issuer"),
					Long.parseLong(env.getProperty("service.jwt.claim.expiration-time"))
					);
			sch = jwt.generate();
	
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
		}
				
		return sch;
	}
}
