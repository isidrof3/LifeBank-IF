package com.setting.process;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.stereotype.Service;

import com.setting.pojo.cuenta.TransaccionesCuentaResponse;
import com.setting.pojo.entity.Cuenta;
import com.setting.pojo.entity.Prestamo;
import com.setting.pojo.entity.Tarjeta;
import com.setting.pojo.entity.Transaccion;
import com.setting.pojo.tarjeta.CreditCard;
import com.setting.pojo.transacciones.TransaccionesProdcutosResponse;
import com.setting.pojo.transacciones.TransaccionesRequest;
import com.setting.pojo.transacciones.Transaction;
import com.setting.repository.CuentaRepository;
import com.setting.repository.PrestamoRepository;
import com.setting.repository.TarjetaRepository;
import com.setting.repository.TransaccionesRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TransaccionesxProductoProcess {

	private CuentaRepository cuentaRepository;
	private TarjetaRepository tarjetaRepository;
	private PrestamoRepository prestamoRepository;
	private TransaccionesRepository transaccionesRepository;
	
	public TransaccionesxProductoProcess(CuentaRepository cuentaRepository, TarjetaRepository tarjetaRepository,
			PrestamoRepository prestamoRepository, TransaccionesRepository transaccionesRepository) {
		this.cuentaRepository = cuentaRepository;
		this.prestamoRepository = prestamoRepository;
		this.tarjetaRepository = tarjetaRepository;
		this.transaccionesRepository = transaccionesRepository;
	}
	
	public TransaccionesProdcutosResponse productosXCliente(TransaccionesRequest request){
		List<Transaccion> transaccionesCuentaList;
		List<Transaccion> transaccionesPrestamoList;
		List<Transaccion> transaccionesTarjetaList;
		List<Prestamo> PrestamoList;
		List<Tarjeta> TarjetaList;
		Cuenta cuenta;
		com.setting.pojo.prestamo.Prestamo transaccionesPrestamoResponse;
		com.setting.pojo.tarjeta.CreditCard transaccionesTarjetaResponse;
		TransaccionesCuentaResponse transaccionesCuentaResponse;
		List<Transaction> listTransaction;
		List<com.setting.pojo.cuenta.Transaction> listTransactionCuenta;
		List<Transaction> listTransactionTarjeta;
		TransaccionesProdcutosResponse response;
		try {
			cuenta = new Cuenta();
			response = new TransaccionesProdcutosResponse();
			listTransaction = null;
			listTransactionTarjeta = null;
			listTransactionCuenta = null;
			transaccionesPrestamoResponse = new com.setting.pojo.prestamo.Prestamo();
			transaccionesCuentaResponse = new TransaccionesCuentaResponse();
			transaccionesTarjetaResponse = new CreditCard();
			//transacciones de cuenta
			cuenta = cuentaRepository.obtener(request.getCuenta());
			transaccionesCuentaList = transaccionesRepository.obtenerTransaccionesCuenta(request.getCliente(), request.getCuenta(),
					"prodCuenta", StringTdDate(request.getFechaInicio()), StringTdDate(request.getFechaFin()));
			
			
			transaccionesCuentaResponse.setEndDate(request.getFechaFin());
			transaccionesCuentaResponse.setId(cuenta.getNumCuenta());
			transaccionesCuentaResponse.setStartDate(request.getFechaInicio());
				for(Transaccion tra: transaccionesCuentaList) {
					com.setting.pojo.cuenta.Transaction transaction = new com.setting.pojo.cuenta.Transaction();
					transaction.setAmount(tra.getMonto());
					transaction.setDate(tra.getFecha().toString());
					transaction.setDescription(tra.getDescripcion());
					listTransactionCuenta.add(transaction);
				}
				
				transaccionesCuentaResponse.setTransactions(listTransactionCuenta);
			
			PrestamoList = prestamoRepository.obtenerPrestamos(request.getCliente(), request.getCuenta());
			transaccionesPrestamoList = transaccionesRepository.obtenerTransaccionesPrestamo(request.getCliente(), request.getCuenta(),
					"prodPrestamo", StringTdDate(request.getFechaInicio()), StringTdDate(request.getFechaFin()));
			
			for(Prestamo prestamo: PrestamoList) {
				transaccionesPrestamoResponse.setDebt(prestamo.getRestantePagar());
				transaccionesPrestamoResponse.setEndDate(request.getFechaFin());
				transaccionesPrestamoResponse.setId(prestamo.getCodigo());
				transaccionesPrestamoResponse.setInterestAmount(prestamo.getInteresAcumulado());
				transaccionesPrestamoResponse.setInterestRate(prestamo.getTasaInteres());
				transaccionesPrestamoResponse.setStartDate(request.getFechaInicio());
				transaccionesPrestamoResponse.setTotal(Integer.parseInt(prestamo.getTotal().toString()));
				for(Transaccion tra: transaccionesPrestamoList) {
					Transaction transaction = new Transaction();
					transaction.setAmount(tra.getMonto());
					transaction.setDate(tra.getFecha().toString());
					transaction.setDescription(tra.getDescripcion());
					listTransaction.add(transaction);
				}
				
				transaccionesPrestamoResponse.setTransactions(listTransaction);
			}
			
			TarjetaList = tarjetaRepository.obtenerTarjetas(request.getCliente(), request.getCuenta());
			transaccionesTarjetaList = transaccionesRepository.obtenerTransaccionesTarjeta(request.getCliente(), request.getCuenta(),
					"prodTarjeta", StringTdDate(request.getFechaInicio()), StringTdDate(request.getFechaFin()));
			

			for(Tarjeta tarjeta: TarjetaList) {
				transaccionesTarjetaResponse.setAvailable(tarjeta.getDisponible());
				transaccionesTarjetaResponse.setEndDate(request.getFechaFin());
				transaccionesTarjetaResponse.setId(tarjeta.getNumTarjeta());
				transaccionesTarjetaResponse.setInterestAmount(tarjeta.getInteresAcumulado());
				transaccionesTarjetaResponse.setInterestRate(tarjeta.getTasaInteres());
				transaccionesTarjetaResponse.setLimit(tarjeta.getLimite());
				transaccionesTarjetaResponse.setMonthlyCut(Integer.parseInt(tarjeta.getFechaCorte()));
				transaccionesTarjetaResponse.setStartDate(request.getFechaInicio());
				
				for(Transaccion tra: transaccionesPrestamoList) {
					Transaction transaction = new Transaction();
					transaction.setAmount(tra.getMonto());
					transaction.setDate(tra.getFecha().toString());
					transaction.setDescription(tra.getDescripcion());
					listTransactionTarjeta.add(transaction);
				}
				
				transaccionesTarjetaResponse.setTransactions(listTransactionTarjeta);
			}

			response.setCreditCard(transaccionesTarjetaResponse);
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			response = null;
		}
		
		return response;
	}
	
	private java.sql.Date StringTdDate(String fecha) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		java.sql.Date sqlDate;
			try {
				java.util.Date date = formatter.parse(fecha);
				sqlDate = new Date(date.getTime());
			} catch (ParseException e) {
				log.error(e.getMessage());
				sqlDate = null;
			}
			
		return sqlDate;
	}
}
