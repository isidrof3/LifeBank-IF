package com.setting.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.setting.pojo.entity.Usuario;

public interface UsuarioRepository extends CrudRepository<Usuario, String>{
	
	@Query(value = "select * " + 
			"	from usr_usuario " + 
			"	where usr_usuario = :usuario " + 
			"      and usr_password = :password ;", nativeQuery = true)
	public Usuario obtenerUsuario(@Param("usuario") String usuario, @Param("password") String password);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update lifebank.usr_usuario " + 
			"	set usr_intentos_fallidos = :intentos " + 
			"	where usr_usuario = :usuario ;", nativeQuery = true)
	public int ActualizarIntentos(@Param("usuario") String usuario, @Param("intentos") Integer intentos);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value = "update lifebank.usr_usuario " + 
			"	set usr_estado = :estado " + 
			"	where usr_usuario = :usuario ;", nativeQuery = true)
	public int ActualizarEstado(@Param("usuario") String usuario, @Param("estado") String estado);
	
	@Query(value="select * from lifebank.usr_usuario  where usr_usuario = :usuario ;", nativeQuery = true)
public Usuario obtenerUsuarioporID(@Param("usuario") String usuario);
}
