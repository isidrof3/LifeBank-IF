package com.lifebank.utility;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
public class RestClient {
	private RestTemplate restTemplate;
	
	@Autowired
	public RestClient(RestTemplate restTemplate){
		this.restTemplate = restTemplate;
	}
		
	public <T, U> U call(String url, HttpMethod method, Map<String, String> headers, T requestObject, ParameterizedTypeReference<U> responseType,
			Object... uriParams) throws RestClientException {
		MultiValueMap<String, String> mapHeaders = new LinkedMultiValueMap<>();
		ResponseEntity<U> response;

		//headers.add("Authorization", "Basic");
		
		if(headers != null && !headers.isEmpty()) 
			headers.forEach((key, value) -> mapHeaders.add(key, value));
		else {
			mapHeaders.add("Accept", MediaType.APPLICATION_JSON_UTF8_VALUE);
			mapHeaders.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);
		}
		
		return restTemplate
			.exchange(
				url, 
				method,
				new HttpEntity<>(requestObject, mapHeaders),
				responseType,
				uriParams
			)
			.getBody();
	}
}
