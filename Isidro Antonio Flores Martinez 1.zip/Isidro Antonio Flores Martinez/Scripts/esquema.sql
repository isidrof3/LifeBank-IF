-- DROP SCHEMA lifebank;

CREATE SCHEMA lifebank AUTHORIZATION postgres;
