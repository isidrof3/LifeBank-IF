package com.setting.utility;

public class SettingsProperties
{
	private SettingsProperties() {}
	
	public static class error
	{
		private static final String usuarioNoExisteMsg  = "Usuario no existe, verifique las credenciales";
		private static final String usuarioNoExisteCode  = "998";
		
		public static String getUsuarioNoExisteMsg()
		{
			return usuarioNoExisteMsg;
		}
		
		public static String getUsuarioNoExisteCode()
		{
			return usuarioNoExisteCode;
		}
	}
	
	public static class users
	{
		private static final String usuario_Setting  = "User_Setting";
		
		
		public static String getUsuario_Setting()
		{
			return usuario_Setting;
		}
	}
}
