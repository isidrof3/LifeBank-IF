package com.setting.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.setting.pojo.entity.Transaccion;


public interface TransaccionesRepository extends CrudRepository<Transaccion, String>{
	
	@Query(value="select tra.* " + 
			"	from prs_prestamo prs,tra_transaccion tra " + 
			"	where prs.prs_num_cuenta = tra.tra_cuenta_origen " + 
			"	  and prs.prs_pro_codigo = tra.tra_pro_codigo " + 
			"	  and prs_cli_codigo = :cliente " + 
			"	  and prs_num_cuenta = :cuenta " + 
			"	  and prs_pro_codigo = :producto " + 
			"	  and prs_fecha >= :fechaInicio " + 
			"	  and prs_fecha <= :fechaFin " + 
			"	 order by prs_fecha_creacion ;", nativeQuery = true)
	public List<Transaccion> obtenerTransaccionesCuenta(@Param("cliente") String cliente, @Param("cuenta") String cuenta,
			@Param("producto") String producto, @Param("fechaInicio") Date fechaInicio, @Param("fechaFin") Date fechaFin);


	@Query(value="select tra.* " + 
			"	from tar_tarjeta prs, tra_transaccion tra " + 
			"	where prs.tar_num_cuenta = tra.tra_cuenta_origen " + 
			"	  and prs.tar_pro_codigo = tra.tra_pro_codigo " + 
			"	  and tar_cli_codigo = :cliente " + 
			"	  and tar_num_cuenta = :cuenta " + 
			"	  and tar_pro_codigo = :producto " + 
			"	  and tra.tra_fecha >= :fechaInicio " + 
			"	  and tra.tra_fecha <= :fechaFin " + 
			"	 order by tar_fecha_creacion ; ", nativeQuery = true)
	public List<Transaccion> obtenerTransaccionesTarjeta(@Param("cliente") String cliente, @Param("cuenta") String cuenta,
			@Param("producto") String producto, @Param("fechaInicio") Date fechaInicio, @Param("fechaFin") Date fechaFin);


	@Query(value="select tra.* " + 
			"	from cta_cuenta cta, tra_transaccion tra " + 
			"	where cta.cta_num_cuenta = tra.tra_cuenta_origen " + 
			"	  and cta.cta_pro_codigo = tra.tra_pro_codigo " + 
			"	  and cta_cli_codigo = :cliente " + 
			"	  and cta_num_cuenta = :cuenta " + 
			"	  and cta_pro_codigo = :producto " + 
			"	  and tra.tra_fecha >= :fechaInicio " + 
			"	  and tra.tra_fecha <= :fechaFin " + 
			"	 order by cta_fecha_creacion ; ", nativeQuery = true)
	public List<Transaccion> obtenerTransaccionesPrestamo(@Param("cliente") String cliente, @Param("cuenta") String cuenta,
			@Param("producto") String producto, @Param("fechaInicio") Date fechaInicio, @Param("fechaFin") Date fechaFin);

}
