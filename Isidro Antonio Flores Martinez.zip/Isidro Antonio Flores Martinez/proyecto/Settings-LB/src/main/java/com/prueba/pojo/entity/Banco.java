package com.prueba.pojo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity(name = "lb_banco")
@Data
public class Banco {
	@Id
	@Column(name = "id_banco")		
	private Integer banco;		

	@Column(name = "nombre")
	private String nombre;

}