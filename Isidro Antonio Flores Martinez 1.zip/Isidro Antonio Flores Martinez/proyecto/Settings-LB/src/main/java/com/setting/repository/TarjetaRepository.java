package com.setting.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.setting.pojo.entity.Tarjeta;


public interface TarjetaRepository extends CrudRepository<Tarjeta, String>{
	
	@Query(value="select * " + 
			"	from tar_tarjeta " + 
			"	where tar_cli_codigo = :cliente " + 
			"	  and tar_num_cuenta = :cuenta ;", nativeQuery = true)
	public List<Tarjeta> obtenerTarjetas(@Param("cliente") String cliente, @Param("cuenta") String cuenta);
	
}
