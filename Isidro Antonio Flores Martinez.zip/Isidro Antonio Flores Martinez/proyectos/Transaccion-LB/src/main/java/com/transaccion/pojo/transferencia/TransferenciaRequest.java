
package com.transaccion.pojo.transferencia;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cuentaOrigen",
    "cuentaDestino",
    "monto"
})
public class TransferenciaRequest {

    @JsonProperty("cuentaOrigen")
    private String cuentaOrigen;
    @JsonProperty("cuentaDestino")
    private String cuentaDestino;
    @JsonProperty("monto")
    private Double monto;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cuentaOrigen")
    public String getCuentaOrigen() {
        return cuentaOrigen;
    }

    @JsonProperty("cuentaOrigen")
    public void setCuentaOrigen(String cuentaOrigen) {
        this.cuentaOrigen = cuentaOrigen;
    }

    @JsonProperty("cuentaDestino")
    public String getCuentaDestino() {
        return cuentaDestino;
    }

    @JsonProperty("cuentaDestino")
    public void setCuentaDestino(String cuentaDestino) {
        this.cuentaDestino = cuentaDestino;
    }

    @JsonProperty("monto")
    public Double getMonto() {
        return monto;
    }

    @JsonProperty("monto")
    public void setMonto(Double monto) {
        this.monto = monto;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
}
