package com.setting.pojo.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity(name = "cli_cliente")
@Data
public class Cliente {
	@Id
	@Column(name = "cli_codigo")		
	private String codigo;		

	@Column(name = "cli_nombre")
	private String nombre;
	
	@Column(name = "cli_apellido")
	private String apellido;
	
	@Column(name = "cli_telefono")
	private String telefono;
	
	@Column(name = "cli_saldo")
	private Double saldo;
	
	@Column(name = "cli_correo_electronico")
	private String correo;
	
	@Column(name = "cli_fecha_creacion")
	private Date fechaCreacion;
	
	@Column(name = "cli_creado_por")
	private String creadoPor;
	
	@Column(name = "cli_fecha_modificacion")
	private Date fechaModificacion;
	
	@Column(name = "cli_modificado_por")
	private String modificadoPor;

}