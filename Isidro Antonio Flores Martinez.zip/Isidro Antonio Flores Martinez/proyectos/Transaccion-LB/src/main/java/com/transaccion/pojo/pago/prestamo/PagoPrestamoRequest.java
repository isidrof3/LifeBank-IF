
package com.transaccion.pojo.pago.prestamo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "idCuenta",
    "idPrestamo",
    "monto"
})
public class PagoPrestamoRequest {

    @JsonProperty("idCuenta")
    private String idCuenta;
    @JsonProperty("idPrestamo")
    private String idPrestamo;
    @JsonProperty("monto")
    private Double monto;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("idCuenta")
    public String getIdCuenta() {
        return idCuenta;
    }

    @JsonProperty("idCuenta")
    public void setIdCuenta(String idCuenta) {
        this.idCuenta = idCuenta;
    }

    @JsonProperty("idPrestamo")
    public String getIdPrestamo() {
        return idPrestamo;
    }

    @JsonProperty("idPrestamo")
    public void setIdPrestamo(String idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    @JsonProperty("monto")
    public Double getMonto() {
        return monto;
    }

    @JsonProperty("monto")
    public void setMonto(Double monto) {
        this.monto = monto;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
}
