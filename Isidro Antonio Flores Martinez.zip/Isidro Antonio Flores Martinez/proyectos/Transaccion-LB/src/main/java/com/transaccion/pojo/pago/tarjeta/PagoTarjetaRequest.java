
package com.transaccion.pojo.pago.tarjeta;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "idCuenta",
    "idTarjeta",
    "monto"
})
public class PagoTarjetaRequest {

    @JsonProperty("idCuenta")
    private String idCuenta;
    @JsonProperty("idTarjeta")
    private String idTarjeta;
    @JsonProperty("monto")
    private Double monto;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("idCuenta")
    public String getIdCuenta() {
        return idCuenta;
    }

    @JsonProperty("idCuenta")
    public void setIdCuenta(String idCuenta) {
        this.idCuenta = idCuenta;
    }

    @JsonProperty("idTarjeta")
    public String getIdTarjeta() {
        return idTarjeta;
    }

    @JsonProperty("idTarjeta")
    public void setIdTarjeta(String idTarjeta) {
        this.idTarjeta = idTarjeta;
    }

    @JsonProperty("monto")
    public Double getMonto() {
        return monto;
    }

    @JsonProperty("monto")
    public void setMonto(Double monto) {
        this.monto = monto;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
