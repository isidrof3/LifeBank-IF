package com.lifebank.process;

import org.springframework.stereotype.Service;

import com.lifebank.pojo.autenticacion.AutenticacionRequest;
import com.lifebank.pojo.autenticacion.AutenticacionResponse;
import com.lifebank.pojo.autenticacion.Body;
import com.lifebank.pojo.autenticacion.Header;
import com.lifebank.pojo.usuario.UsuarioResponse;
import com.lifebank.process.usuario.ActualizaEstadoProcess;
import com.lifebank.process.usuario.ActualizarIntentosFallidos;
import com.lifebank.process.usuario.ObtenerUsuarioProcess;
import com.lifebank.utility.LifeBankProperties.error;
import com.lifebank.utility.LifeBankProperties.success;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AutenticacionProcess {

	private ObtenerUsuarioProcess obtenerUsuarioProcess;
	private CifrarCredenciales cifrarCredenciales;
	private GenerarTokenProcess generarTokenProcess;
	private ActualizarIntentosFallidos actualizaIntentos;
	private ActualizaEstadoProcess actualizaEstadoProcess;
	
	public AutenticacionProcess(ObtenerUsuarioProcess obtenerUsuarioProcess, CifrarCredenciales cifrarCredenciales,
			GenerarTokenProcess generarTokenProcess, ActualizarIntentosFallidos actualizaIntentos, ActualizaEstadoProcess actualizaEstadoProcess) {
		this.obtenerUsuarioProcess = obtenerUsuarioProcess;
		this.cifrarCredenciales =  cifrarCredenciales;
		this.generarTokenProcess = generarTokenProcess;
		this.actualizaIntentos = actualizaIntentos;
		this.actualizaEstadoProcess = actualizaEstadoProcess;
	}
	
	public AutenticacionResponse autenticar(AutenticacionRequest request) {
		AutenticacionResponse response;
		UsuarioResponse usuarioResponse;
		Header header;
		Body body;
		String cadenaCifrada;
		try {
			//inicializando objetos
			cadenaCifrada = "";
			header = new Header();
			body = new Body();
			response = new AutenticacionResponse();
			usuarioResponse = new UsuarioResponse();
			
			//se obtiene las credenciales cifradas
			cadenaCifrada = cifrarCredenciales.cifrar(request.getUsuario(),request.getPassword());
			
			//se valida si el usuario existe en la base de datos
			usuarioResponse = obtenerUsuarioProcess.obtenerUsuario(request.getUsuario(),cadenaCifrada);
			
			if(usuarioResponse != null) {
				if((success.getSuccess_code()).equals(usuarioResponse.getHeader().getCode())) {
					//las credenciales son correctas y se genera el token
					body.setTkn(generarTokenProcess.generarJWT(usuarioResponse, request.getip()));
					
					header.setCode(success.getsuccess_HTTP());
					header.setMessage(success.getsuccess_Msg());
					response.setHeader(header);
					response.setBody(body);
				}else if((error.getUsuarioNoExisteCode()).equals(usuarioResponse.getHeader().getCode())) {
					//las credenciales no existen, se agrega un logueo fallido
					usuarioResponse = obtenerUsuarioProcess.obtenerUsuarioxID(request.getUsuario());
					
					if(usuarioResponse != null) {
						usuarioResponse = actualizaIntentos.ActualizaIntentos(request.getUsuario(), usuarioResponse.getBody().getIntentosFallidos() + 1);
						if(usuarioResponse!= null) {
							if(usuarioResponse.getBody().getIntentosFallidos() >=5) {
								log.info("Cuenta bloqueada");
								actualizaEstadoProcess.ActualizaEstado(request.getUsuario(), "B");
								header.setCode(error.geterror_HTTP());
								response.setHeader(header);
							}
						}
						
					}else {
						header.setCode(error.geterror_autenticacion());
						response.setHeader(header);
					}
						
				}
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			header= new Header();
			response = new AutenticacionResponse();
			header.setMessage(e.getMessage());
			header.setCode(error.getErrorGeneralCode());
			response.setHeader(header);
		}
		
		return response;
	}
}
