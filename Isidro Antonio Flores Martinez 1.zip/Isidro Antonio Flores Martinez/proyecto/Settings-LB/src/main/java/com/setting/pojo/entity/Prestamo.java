package com.setting.pojo.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity(name = "prs_prestamo")
@Data
public class Prestamo {
	@Id
	@Column(name = "prs_codigo")		
	private String codigo;		

	@Column(name = "prs_cli_codigo")
	private String cliCodigo;
	
	@Column(name = "prs_fecha")
	private Date fecha;
	
	@Column(name = "prs_total")
	private Double total;
	
	@Column(name = "prs_fiador")
	private String fiador;
	
	@Column(name = "prs_pro_codigo")
	private String codigoProducto;
	
	@Column(name = "prs_fecha_creacion")
	private Date fechaCreacion;
	
	@Column(name = "prs_creado_por")
	private String creadoPor;
	
	@Column(name = "prs_fecha_modificacion")
	private Date fechaModificacion;
	
	@Column(name = "prs_modificado_por")
	private String modificadoPor;
	
	@Column(name = "prs_num_cuenta")
	private String numCuenta;
	
	@Column(name = "prs_restante_pagar")
	private Double restantePagar;

	@Column(name = "prs_tasa_interes")
	private Double tasaInteres;

	@Column(name = "prs_interes_acumulado")
	private Double interesAcumulado;

}