package com.lifebank.process.usuario;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.lifebank.pojo.usuario.ActualizaEstadoRequest;
import com.lifebank.pojo.usuario.UsuarioResponse;
import com.lifebank.utility.RestClient;
import com.lifebank.utility.ServiceUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ActualizaEstadoProcess {
	private Environment env;
	private RestClient restClient;
	
	public ActualizaEstadoProcess( Environment env, RestClient restClient) {
		
		this.env = env;
		this.restClient = restClient;
		
	}
	
	public UsuarioResponse ActualizaEstado(String usuario, String estado) {
		UsuarioResponse response;
		ActualizaEstadoRequest request;
		try {
			request = new ActualizaEstadoRequest();
			
			request.setIntentos(estado);
			request.setUsuario(usuario);
			
			String actualizaUrl = env.getProperty("service.setting.actualizaEstado.url");
			log.error("Request ActualizaEstado: " + request);
			response = restClient.call(actualizaUrl, HttpMethod.POST, null, request, new ParameterizedTypeReference<UsuarioResponse>() {});
			log.error("Response ActualizaEstado: " + ServiceUtils.objToString(response));
	
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			response = new UsuarioResponse();
		}
		
		return response;
	}

}
