package com.lifebank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lifebank.pojo.autenticacion.AutenticacionRequest;
import com.lifebank.pojo.autenticacion.AutenticacionResponse;
import com.lifebank.process.AutenticacionProcess;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {
private AutenticacionProcess proc;
	
	@Autowired
	public UsuarioController(AutenticacionProcess proc)
	{
		this.proc = proc;
	}
	
	@PostMapping("/autenticar")
	public AutenticacionResponse obtenerUsuario (@RequestBody AutenticacionRequest request)
	{

			return proc.autenticar(request); 
		
	}
	
}

