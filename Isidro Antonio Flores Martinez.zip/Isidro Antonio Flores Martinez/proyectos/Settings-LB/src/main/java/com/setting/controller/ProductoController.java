package com.setting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.setting.pojo.response.WrapperResponse;
import com.setting.pojo.transacciones.TransaccionesProdcutosResponse;
import com.setting.pojo.transacciones.TransaccionesRequest;
import com.setting.process.JsonProcess;

@RestController
@RequestMapping("/transaccion")
public class ProductoController {
private JsonProcess proc;
	
	@Autowired
	public ProductoController(JsonProcess jsPro)
	{
		this.proc = jsPro;
	}
	
	@PostMapping("/detalle")
	public WrapperResponse<TransaccionesProdcutosResponse> obtenerUsuario (@RequestBody TransaccionesRequest request)
	{

			return proc.TransaccionesProductos(request); 
		
	}
	
}

