package com.prueba.pojo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity(name = "lb_cliente")
@Data
public class Cliente {
	@Id
	@Column(name = "id_cliente")		
	private Integer id;		

	@Column(name = "nombre")
	private String nombre;
	
	@Column(name = "apellido")
	private String apellido;
	
	@Column(name = "telefono")
	private String telefono;
	
	@Column(name = "saldo")
	private String saldo;
	
	@Column(name = "correo_electronico")
	private String correo;

}