package com.setting.process;

import org.springframework.stereotype.Service;

import com.setting.pojo.entity.Cliente;
import com.setting.pojo.entity.Usuario;
import com.setting.pojo.usuariocliente.request.UsuarioClienteRequest;
import com.setting.utility.SettingsProperties.users;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ManejarUsuarioClienteProcess {

	private ClienteProcess clienteProcess;
	private UsuarioProcess usuarioProcess;
	
	public ManejarUsuarioClienteProcess(ClienteProcess clienteProcess, UsuarioProcess usuarioProcess) {
		this.clienteProcess = clienteProcess;
		this.usuarioProcess = usuarioProcess;
	}
	
	public Boolean agregarClienteUsuario(UsuarioClienteRequest request) {
		Boolean resultado;
		Cliente cliente;
		Usuario usuario;
		java.util.Date uDate = new java.util.Date();
		java.sql.Date fechaHoy;
		try {
			cliente = new Cliente();
			usuario = new Usuario();
			fechaHoy = new java.sql.Date(uDate.getTime());
			resultado = false;
			
			//insertando cliente
			cliente.setCodigo(request.getCodigo());
			cliente.setApellido(request.getApellido());
			cliente.setCorreo(request.getCorreo());
			cliente.setCreadoPor(users.getUsuario_Setting());
			cliente.setFechaCreacion(fechaHoy);
			cliente.setNombre(request.getNombre());
			cliente.setTelefono(request.getTelefono());
			cliente.setSaldo(0.0);
			resultado = clienteProcess.agregarCliente(cliente);
			
			if(resultado) {
				//insertando usuario
				usuario.setUsuario(request.getUsuario());
				usuario.setPassword(request.getPassword());
				usuario.setCliCodigo(request.getCodigo());
				usuario.setFechaCreacion(fechaHoy);
				usuario.setCreadoPor(users.getUsuario_Setting());
				resultado = usuarioProcess.agregarUsuario(usuario);
			}

			
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			resultado = false;
		}
		
		return resultado;
	}
}
