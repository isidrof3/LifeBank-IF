package com.setting.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.setting.pojo.entity.Prestamo;

public interface PrestamoRepository extends CrudRepository<Prestamo, String>{
	
	@Query(value="select * " + 
			"	from prs_prestamo " + 
			"	where prs_cli_codigo = :cliente " + 
			"	  and prs_num_cuenta = :cuenta ; ", nativeQuery = true)
	public List<Prestamo> obtenerPrestamos(@Param("cliente") String cliente, @Param("cuenta") String cuenta);
	
}
