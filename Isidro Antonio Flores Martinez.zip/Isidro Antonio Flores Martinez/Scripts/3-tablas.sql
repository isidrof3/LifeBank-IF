CREATE TABLE lifebank.bnc_banco (
	bnc_codigo varchar NOT NULL,
	bnc_nombre varchar NULL,
	bnc_fecha_creacion date NULL,
	bnc_creado_por varchar NULL,
	bnc_fecha_modificacion date NULL,
	bnc_modificado_por varchar NULL,
	CONSTRAINT bnc_banco_pk PRIMARY KEY (bnc_codigo)
);

CREATE TABLE lifebank.cli_cliente (
	cli_codigo varchar NOT NULL,
	cli_nombre varchar NULL,
	cli_apellido varchar NULL,
	cli_telefono varchar NULL,
	cli_saldo numeric NULL,
	cli_correo_electronico varchar NULL,
	cli_fecha_creacion date NULL,
	cli_creado_por varchar NULL,
	cli_fecha_modificacion date NULL,
	cli_modificado_por varchar NULL,
	CONSTRAINT cli_cliente_pk PRIMARY KEY (cli_codigo)
);

INSERT INTO lifebank.cli_cliente
(cli_codigo, cli_nombre, cli_apellido, cli_telefono, cli_saldo, cli_correo_electronico, cli_fecha_creacion, cli_creado_por, cli_fecha_modificacion, cli_modificado_por)
VALUES('12345', 'Juan', 'Perez', '78564321', 0, '123@prueba.com', '2019-05-10', 'User_Setting', NULL, NULL);
commit;

CREATE TABLE lifebank.cta_cuenta (
	cta_cli_codigo varchar NULL,
	cta_num_cuenta varchar NOT NULL,
	cta_tipo_cuenta varchar NULL,
	cta_fecha_creacion date NULL,
	cta_creado_por varchar NULL,
	cta_fecha_modificacion date NULL,
	cta_modificado_por varchar NULL,
	cta_pro_codigo varchar NULL,
	CONSTRAINT cta_cuenta_pk PRIMARY KEY (cta_num_cuenta)
);

INSERT INTO lifebank.cta_cuenta
(cta_cli_codigo, cta_num_cuenta, cta_tipo_cuenta, cta_fecha_creacion, cta_creado_por, cta_fecha_modificacion, cta_modificado_por, cta_pro_codigo)
VALUES('12345', '1111111', 'Ahorro', '2019-05-11', 'LBank', NULL, NULL, 'prodCuenta');
commit;

CREATE TABLE lifebank.tar_tarjeta (
	tar_cli_codigo varchar NULL,
	tar_num_tarjeta varchar NOT NULL,
	tar_tipo_tarjeta varchar NULL,
	tar_fecha_creacion date NULL,
	tar_creado_por varchar NULL,
	tar_fecha_modificacion date NULL,
	tar_modificado_por varchar NULL,
	tar_pro_codigo varchar NULL,
	tar_num_cuenta varchar NULL,
	tar_limite int4 NULL,
	tar_disponible numeric NULL,
	tar_tasa_interes numeric NULL,
	tar_intereses_acumulados numeric NULL,
	tar_fecha_corte varchar NULL,
	CONSTRAINT tar_tarjeta_pk PRIMARY KEY (tar_num_tarjeta)
);

INSERT INTO lifebank.tar_tarjeta
(tar_cli_codigo, tar_num_tarjeta, tar_tipo_tarjeta, tar_fecha_creacion, tar_creado_por, tar_fecha_modificacion, tar_modificado_por, tar_pro_codigo, tar_num_cuenta, tar_limite, tar_disponible, tar_tasa_interes, tar_intereses_acumulados, tar_fecha_corte)
VALUES('12345', '77777777', 'C', '2019-05-11', 'LBank', NULL, NULL, 'prodTarjeta', '1111111', 4500, 3262.15, 5.25, 125.43, '18');
commit;

CREATE TABLE lifebank.tra_transaccion (
	tra_transaccion serial NOT NULL,
	tra_cli_codigo varchar NULL,
	tra_num_autorizacion varchar NULL,
	tra_fecha date NULL,
	tra_pro_codigo varchar NULL,
	tra_monto numeric NULL,
	tra_cuenta_origen varchar NULL,
	tra_cuenta_destino varchar NULL,
	tra_fecha_creacion date NULL,
	tra_creado_por varchar NULL,
	tra_fecha_modificacion date NULL,
	tra_modificado_por varchar NULL,
	tra_descripcion varchar NULL,
	CONSTRAINT tra_transaccion_pk PRIMARY KEY (tra_transaccion)
);

INSERT INTO lifebank.tra_transaccion
(tra_transaccion, tra_cli_codigo, tra_num_autorizacion, tra_fecha, tra_pro_codigo, tra_monto, tra_cuenta_origen, tra_cuenta_destino, tra_fecha_creacion, tra_creado_por, tra_fecha_modificacion, tra_modificado_por, tra_descripcion)
VALUES(1, '12345', '1231245343', '2019-05-11', 'prodCuenta', 100, '1111111', '1111111', '2019-05-11', 'LBank', NULL, NULL, 'Amazon payments');
INSERT INTO lifebank.tra_transaccion
(tra_transaccion, tra_cli_codigo, tra_num_autorizacion, tra_fecha, tra_pro_codigo, tra_monto, tra_cuenta_origen, tra_cuenta_destino, tra_fecha_creacion, tra_creado_por, tra_fecha_modificacion, tra_modificado_por, tra_descripcion)
VALUES(2, '12345', '1231245444', '2019-05-11', 'prodTarjeta', 360, '1111111', '1111111', '2019-05-11', 'LBank', NULL, NULL, 'Credit card payment');
INSERT INTO lifebank.tra_transaccion
(tra_transaccion, tra_cli_codigo, tra_num_autorizacion, tra_fecha, tra_pro_codigo, tra_monto, tra_cuenta_origen, tra_cuenta_destino, tra_fecha_creacion, tra_creado_por, tra_fecha_modificacion, tra_modificado_por, tra_descripcion)
VALUES(3, '12345', '1231245555', '2019-05-11', 'prodPrestamo', 1000, '1111111', '1111111', '2019-05-11', 'LBank', NULL, NULL, 'Loan payment');
commit;

CREATE TABLE lifebank.usr_usuario (
	usr_usuario varchar NOT NULL,
	usr_password varchar NULL,
	usr_cli_codigo varchar NULL,
	usr_fecha_creacion date NULL,
	usr_creado_por varchar NULL,
	usr_fecha_modificacion date NULL,
	usr_modificado_por varchar NULL,
	usr_intentos_fallidos int4 NULL,
	usr_estado varchar NULL,
	CONSTRAINT usr_usuario_pk PRIMARY KEY (usr_usuario)
);

INSERT INTO lifebank.usr_usuario
(usr_usuario, usr_password, usr_cli_codigo, usr_fecha_creacion, usr_creado_por, usr_fecha_modificacion, usr_modificado_por, usr_intentos_fallidos, usr_estado)
VALUES('hulk', 'e4bb63ce8d912b892110c3a13b98da2637787c4b20319b57dd7c4bb110dda9dc19909279912ac3dbb2181938fa60aff6b549f66b2a906a47484fa3a02c856d65', '12345', '2019-05-10', NULL, NULL, NULL, 24, NULL);


CREATE TABLE lifebank.pro_producto (
	pro_codigo varchar NOT NULL DEFAULT nextval('pro_producto_pro_codigo_seq'::regclass),
	pro_nombre varchar NULL,
	pro_descripcion varchar NULL,
	pro_fecha_creacion date NULL,
	pro_creado_por varchar NULL,
	pro_fecha_modificacion date NULL,
	pro_modificado_por varchar NULL,
	CONSTRAINT pro_producto_pk PRIMARY KEY (pro_codigo)
);

CREATE TABLE lifebank.prs_prestamo (
	prs_codigo varchar NOT NULL,
	prs_cli_codigo varchar NULL,
	prs_fecha date NULL,
	prs_total numeric NULL,
	prs_fiador varchar NULL,
	prs_pro_codigo varchar NULL,
	prs_fecha_creacion date NULL,
	prs_creado_por varchar NULL,
	prs_fecha_modificacion date NULL,
	prs_modificado_por varchar NULL,
	prs_num_cuenta varchar NULL,
	prs_restante_pagar numeric NULL,
	prs_tasa_interes numeric NULL,
	prs_interes_acumulado numeric NULL,
	CONSTRAINT prs_prestamo_pk PRIMARY KEY (prs_codigo)
);

INSERT INTO lifebank.prs_prestamo
(prs_codigo, prs_cli_codigo, prs_fecha, prs_total, prs_fiador, prs_pro_codigo, prs_fecha_creacion, prs_creado_por, prs_fecha_modificacion, prs_modificado_por, prs_num_cuenta, prs_restante_pagar, prs_tasa_interes, prs_interes_acumulado)
VALUES('pres1', '12345', '2019-05-11', 10000, 'Iron Man', 'prodPrestamo', '2019-05-11', 'LBank', NULL, NULL, '1111111', NULL, NULL, NULL);
commit;
