package com.lifebank.process;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.security.MessageDigest;

import javax.xml.bind.annotation.adapters.HexBinaryAdapter;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CifrarCredenciales {
	
	public CifrarCredenciales() {
		
	}
	
	public String cifrar(String usuario, String password) {
		String cifrado;
		byte[] usuarioBase64;
		byte[] passwordBase64;
		byte[] bytesCifrar;
		MessageDigest md = null;
		try {
			cifrado = "";
			//codificando usuario a BASE64
			usuarioBase64 = Base64.encodeBase64(usuario.getBytes());
			
			//codificando password a BASE64 
			passwordBase64 = Base64.encodeBase64(password.getBytes()); 
			
			bytesCifrar = ByteBuffer.allocate(usuarioBase64.length+passwordBase64.length).put(usuarioBase64).put(passwordBase64).array();
			
			//cifrando a SHA512
			md= MessageDigest.getInstance("SHA-512");
			md.update(bytesCifrar);
			cifrado  = String.format("%0128x", new BigInteger(1, md.digest()));
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			cifrado = "";
		}
		
		return cifrado;
	}

}
