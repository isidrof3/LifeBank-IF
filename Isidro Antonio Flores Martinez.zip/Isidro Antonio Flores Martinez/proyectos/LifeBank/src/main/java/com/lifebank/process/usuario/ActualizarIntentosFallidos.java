package com.lifebank.process.usuario;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.lifebank.pojo.usuario.ActualizaIntentosRequest;
import com.lifebank.pojo.usuario.UsuarioResponse;
import com.lifebank.utility.RestClient;
import com.lifebank.utility.ServiceUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ActualizarIntentosFallidos {
	private Environment env;
	private RestClient restClient;
	
	public ActualizarIntentosFallidos( Environment env, RestClient restClient) {
		
		this.env = env;
		this.restClient = restClient;
		
	}
	
	public UsuarioResponse ActualizaIntentos(String usuario, Integer intentos) {
		UsuarioResponse response;
		ActualizaIntentosRequest request;
		try {
			request = new ActualizaIntentosRequest();
			
			request.setIntentos(intentos);
			request.setUsuario(usuario);
			
			String actualizaUrl = env.getProperty("service.setting.actualizaIntentos.url");
			log.error("Request ActualizaIntentos: " + request);
			response = restClient.call(actualizaUrl, HttpMethod.POST, null, request, new ParameterizedTypeReference<UsuarioResponse>() {});
			log.error("Response ActualizaIntentos: " + ServiceUtils.objToString(response));
	
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			response = new UsuarioResponse();
		}
		
		return response;
	}

}
