package com.setting.process;

import org.springframework.stereotype.Service;

import com.setting.pojo.entity.Cliente;
import com.setting.repository.ClienteRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ClienteProcess {
	
private ClienteRepository clienteRepository;
	
	public ClienteProcess(ClienteRepository clienteRepository){
		this.clienteRepository = clienteRepository;
	}
	
	public Boolean agregarCliente(Cliente cliente) throws Exception {
		Boolean resultado;
		Cliente response;
		try {
			resultado = false;
			response = clienteRepository.save(cliente);
			
			if(response != null) {
				resultado = true;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			log.info(e.getMessage());
			resultado = false;
		}
		
		return resultado;
	}

	

}
