package com.lifebank.process.producto;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.lifebank.pojo.producto.Header;
import com.lifebank.pojo.producto.ProductosClientesRequest;
import com.lifebank.pojo.producto.ProductosClientesResponse;
import com.lifebank.utility.LifeBankProperties.error;
import com.lifebank.utility.LifeBankProperties.success;
import com.lifebank.utility.RestClient;
import com.lifebank.utility.ServiceUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ProductosClienteProcess {
	
	private Environment env;
	private RestClient restClient;
	
	public ProductosClienteProcess(Environment env, RestClient restClient) {
		this.env = env;
		this.restClient = restClient;	
	}
	
		public ProductosClientesResponse productosXCliente(String cliente) throws Exception{
			ProductosClientesResponse productosClientesResponse = new ProductosClientesResponse();
			ProductosClientesRequest request;
			ProductosClientesResponse response;
			Header header;
			try {
				header = new Header();
				request = new ProductosClientesRequest();
				request.setCliente(cliente);
				response = new ProductosClientesResponse();
				
				String tpmUrl = env.getProperty("service.setting.productosCliente.url");
				log.error("Request ProductosCliente: " + ServiceUtils.objToString(request));
				productosClientesResponse = restClient.call(tpmUrl, HttpMethod.POST, null, request, new ParameterizedTypeReference<ProductosClientesResponse>() {});
				log.error("Response DbParameter: " + ServiceUtils.objToString(productosClientesResponse));
				
				if((productosClientesResponse != null) && (productosClientesResponse.getBody() != null)) {
					header.setCode(success.getsuccess_HTTP());
					header.setMessage(success.getsuccess_HTTP());
					response.setHeader(header);
					response.setBody(productosClientesResponse.getBody());
				}else {
					header.setCode(error.geterror_HTTP());
					response.setHeader(header);
				}
			} catch (Exception e) {
				// TODO: handle exception
				log.error(e.getMessage());
				throw e;
			}
			
			return productosClientesResponse;
		}
			
}
