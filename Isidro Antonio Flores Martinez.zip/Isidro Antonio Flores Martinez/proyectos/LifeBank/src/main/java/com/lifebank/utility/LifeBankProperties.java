package com.lifebank.utility;

public class LifeBankProperties
{
	private LifeBankProperties() {}
	
	public static class error
	{
		private static final String usuarioNoExisteMsg  = "Usuario no existe, verifique las credenciales";
		private static final String usuarioNoExisteCode  = "998";
		private static final String errorGeneralCode  = "999";
		private static final String error_autenticacion="HTTP 401";
		private static final String error_HTTP = "HTTP 400";
		
		public static String getUsuarioNoExisteMsg()
		{
			return usuarioNoExisteMsg;
		}
		
		public static String getUsuarioNoExisteCode()
		{
			return usuarioNoExisteCode;
		}
		
		public static String getErrorGeneralCode()
		{
			return errorGeneralCode;
		}
		
		public static String geterror_autenticacion()
		{
			return error_autenticacion;
		}
		
		public static String geterror_HTTP()
		{
			return error_HTTP;
		}
	}
	
	public static class success
	{
		private static final String success_code  = "000";
		private static final String success_HTTP  = "HTTP 200";
		private static final String success_Msg  = "SUCCESS";
		
	
		public static String getSuccess_code()
		{
			return success_code;
		}
		
		public static String getsuccess_HTTP()
		{
			return success_HTTP;
		}
		
		public static String getsuccess_Msg()
		{
			return success_Msg;
		}
	}
}
