
package com.setting.pojo.transacciones;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cliente",
    "cuenta",
    "fechaInicio",
    "fechaFin"
})
public class TransaccionesRequest {

    @JsonProperty("cliente")
    private String cliente;
    @JsonProperty("cuenta")
    private String cuenta;
    @JsonProperty("fechaInicio")
    private String fechaInicio;
    @JsonProperty("fechaFin")
    private String fechaFin;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cliente")
    public String getCliente() {
        return cliente;
    }

    @JsonProperty("cliente")
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    @JsonProperty("cuenta")
    public String getCuenta() {
        return cuenta;
    }

    @JsonProperty("cuenta")
    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    @JsonProperty("fechaInicio")
    public String getFechaInicio() {
        return fechaInicio;
    }

    @JsonProperty("fechaInicio")
    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    @JsonProperty("fechaFin")
    public String getFechaFin() {
        return fechaFin;
    }

    @JsonProperty("fechaFin")
    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }


}
