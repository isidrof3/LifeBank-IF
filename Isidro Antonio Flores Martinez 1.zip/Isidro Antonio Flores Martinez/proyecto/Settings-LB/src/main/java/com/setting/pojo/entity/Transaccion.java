package com.setting.pojo.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity(name = "tra_transaccion")
@Data
public class Transaccion {
	@Id
	@Column(name = "tra_transaccion")		
	private Integer numTransaccion;		

	@Column(name = "tra_cli_codigo")
	private String cliCodigo;
	
	@Column(name = "tra_num_autorizacion")
	private String numAutorizacion;
	
	@Column(name = "tra_fecha")
	private Date fecha;
	
	@Column(name = "tra_pro_codigo")
	private Double codigoProducto;
	
	@Column(name = "tra_monto")
	private Double monto;
	
	@Column(name = "tra_cuenta_origen")
	private Date cuentaOrigen;
	
	@Column(name = "tra_cuenta_destino")
	private String cuentaDestino;
	
	@Column(name = "tra_fecha_creacion")
	private Date fechaCreacion;
	
	@Column(name = "tra_creado_por")
	private String creadoPor;
	
	@Column(name = "tra_fecha_modificacion")
	private Date fechaModificacion;
	
	@Column(name = "tra_modificado_por")
	private String modificadoPor;
	
	@Column(name = "tra_descripcion")
	private String descripcion;

}