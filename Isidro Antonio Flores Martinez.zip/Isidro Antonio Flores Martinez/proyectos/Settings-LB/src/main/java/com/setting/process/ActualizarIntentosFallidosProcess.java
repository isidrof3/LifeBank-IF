package com.setting.process;

import org.springframework.stereotype.Service;

import com.setting.pojo.entity.Usuario;
import com.setting.pojo.usuario.ActualizaIntentosRequest;
import com.setting.repository.UsuarioRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ActualizarIntentosFallidosProcess {

	private UsuarioRepository usuarioRepository;
	
	public ActualizarIntentosFallidosProcess(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;
	}
	
	public Usuario actualizarIntentosFallidos(ActualizaIntentosRequest request){
		Integer numero;
		Usuario usuario;
		try {
			usuario = new Usuario();
			numero = null;
			
			numero = usuarioRepository.ActualizarIntentos(request.getUsuario(), request.getIntentos());
			
			if(numero == 1) {
				usuario = usuarioRepository.obtenerUsuarioporID(request.getUsuario());
			}else {
				usuario = null;
			}
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			usuario = null;
		}
		
		return usuario;
	}
}
