package com.setting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.setting.pojo.producto.ProductoResponse;
import com.setting.pojo.producto.ProductosClientesRequest;
import com.setting.pojo.response.WrapperResponse;
import com.setting.process.JsonProcess;

@RestController
@RequestMapping("/producto")
public class TransaccionController {
private JsonProcess proc;
	
	@Autowired
	public TransaccionController(JsonProcess jsPro)
	{
		this.proc = jsPro;
	}
	
	@PostMapping("/xcliente")
	public WrapperResponse<ProductoResponse> obtenerUsuario (@RequestBody ProductosClientesRequest request)
	{

			return proc.ProductosXCliente(request); 
		
	}
	
}

