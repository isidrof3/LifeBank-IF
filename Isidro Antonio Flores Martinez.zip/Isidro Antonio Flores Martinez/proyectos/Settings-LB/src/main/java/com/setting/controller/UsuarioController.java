package com.setting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.setting.pojo.entity.Usuario;
import com.setting.pojo.response.WrapperResponse;
import com.setting.pojo.usuario.ActualizaIntentosRequest;
import com.setting.pojo.usuario.ActualizarEstadoRequest;
import com.setting.pojo.usuario.ObtenerxIdRequest;
import com.setting.pojo.usuario.UsuarioRequest;
import com.setting.process.JsonProcess;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {
private JsonProcess proc;
	
	@Autowired
	public UsuarioController(JsonProcess jsPro)
	{
		this.proc = jsPro;
	}
	
	@PostMapping("/obtener")
	public WrapperResponse<Usuario> obtenerUsuario (@RequestBody UsuarioRequest request)
	{

			return proc.obtenerUsuario(request); 
		
	}
	
	@PostMapping("/obtenerxid")
	public WrapperResponse<Usuario> obtenerUsuarioxId (@RequestBody ObtenerxIdRequest request)
	{

			return proc.obtenerUsuarioxID(request); 
		
	}
	
	@PostMapping("/actualizar/intentos")
	public WrapperResponse<Usuario> actualizarIntentosFallidos (@RequestBody ActualizaIntentosRequest request)
	{

			return proc.actualizarIntentos(request); 
		
	}
	
	@PostMapping("/actualizar/estado")
	public WrapperResponse<Usuario> actualizarIntentosFallidos (@RequestBody ActualizarEstadoRequest request)
	{

			return proc.ActualizaEstado(request); 
		
	}
}

