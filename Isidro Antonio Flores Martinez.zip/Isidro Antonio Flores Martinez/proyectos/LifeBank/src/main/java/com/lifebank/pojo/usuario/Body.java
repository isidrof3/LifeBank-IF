
package com.lifebank.pojo.usuario;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "usuario",
    "password",
    "cliCodigo",
    "fechaCreacion",
    "creadoPor",
    "fechaModificacion",
    "modificadoPor",
    "intentosFallidos",
    "estado"
})
public class Body {

    @JsonProperty("usuario")
    private String usuario;
    @JsonProperty("password")
    private String password;
    @JsonProperty("cliCodigo")
    private String cliCodigo;
    @JsonProperty("fechaCreacion")
    private String fechaCreacion;
    @JsonProperty("creadoPor")
    private String creadoPor;
    @JsonProperty("fechaModificacion")
    private String fechaModificacion;
    @JsonProperty("modificadoPor")
    private String modificadoPor;
    @JsonProperty("intentosFallidos")
    private Integer intentosFallidos;
    @JsonProperty("estado")
    private String estado;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("usuario")
    public String getUsuario() {
        return usuario;
    }

    @JsonProperty("usuario")
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    @JsonProperty("password")
    public String getPassword() {
        return password;
    }

    @JsonProperty("password")
    public void setPassword(String password) {
        this.password = password;
    }

    @JsonProperty("cliCodigo")
    public String getCliCodigo() {
        return cliCodigo;
    }

    @JsonProperty("cliCodigo")
    public void setCliCodigo(String cliCodigo) {
        this.cliCodigo = cliCodigo;
    }

    @JsonProperty("fechaCreacion")
    public String getFechaCreacion() {
        return fechaCreacion;
    }

    @JsonProperty("fechaCreacion")
    public void setFechaCreacion(String fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    @JsonProperty("creadoPor")
    public String getCreadoPor() {
        return creadoPor;
    }

    @JsonProperty("creadoPor")
    public void setCreadoPor(String creadoPor) {
        this.creadoPor = creadoPor;
    }

    @JsonProperty("fechaModificacion")
    public String getFechaModificacion() {
        return fechaModificacion;
    }

    @JsonProperty("fechaModificacion")
    public void setFechaModificacion(String fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }

    @JsonProperty("modificadoPor")
    public String getModificadoPor() {
        return modificadoPor;
    }

    @JsonProperty("modificadoPor")
    public void setModificadoPor(String modificadoPor) {
        this.modificadoPor = modificadoPor;
    }
    
    @JsonProperty("intentosFallidos")
    public Integer getIntentosFallidos() {
        return intentosFallidos;
    }

    @JsonProperty("intentosFallidos")
    public void setintentosFallidos(Integer intentosFallidos) {
        this.intentosFallidos = intentosFallidos;
    }
    
    @JsonProperty("estado")
    public String getestado() {
        return estado;
    }

    @JsonProperty("estado")
    public void setEstado(String estado) {
        this.estado = estado;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
}
