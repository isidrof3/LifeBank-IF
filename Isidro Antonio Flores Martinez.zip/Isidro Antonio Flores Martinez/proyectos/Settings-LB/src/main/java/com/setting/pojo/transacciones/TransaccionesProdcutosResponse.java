
package com.setting.pojo.transacciones;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.setting.pojo.prestamo.Prestamo;
import com.setting.pojo.tarjeta.CreditCard;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cuenta",
    "creditCard",
    "prestamo"
})
public class TransaccionesProdcutosResponse {

    @JsonProperty("cuenta")
    private Cuenta cuenta;
    @JsonProperty("creditCard")
    private CreditCard creditCard;
    @JsonProperty("prestamo")
    private Prestamo prestamo;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cuenta")
    public Cuenta getCuenta() {
        return cuenta;
    }

    @JsonProperty("cuenta")
    public void setCuenta(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

    @JsonProperty("creditCard")
    public CreditCard getCreditCard() {
        return creditCard;
    }

    @JsonProperty("creditCard")
    public void setCreditCard(CreditCard creditCard) {
        this.creditCard = creditCard;
    }

    @JsonProperty("prestamo")
    public Prestamo getPrestamo() {
        return prestamo;
    }

    @JsonProperty("prestamo")
    public void setPrestamo(Prestamo prestamo) {
        this.prestamo = prestamo;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
