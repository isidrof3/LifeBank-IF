package com.setting.pojo.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity(name = "tar_tarjeta")
@Data
public class Tarjeta {
	@Id
	@Column(name = "tar_num_tarjeta")		
	private String numTarjeta	;		

	@Column(name = "tar_cli_codigo")		
	private String cliCodigo	;	
	
	@Column(name = "tar_tipo_tarjeta")
	private String tipoTarjeta;
	
	@Column(name = "tar_fecha_creacion")
	private Date fechaCreacion;
	
	@Column(name = "tar_creado_por")
	private String creadoPor;
	
	@Column(name = "tar_fecha_modificacion")
	private Date fechaModificacion;
	
	@Column(name = "tar_modificado_por")
	private String modificadoPor;
	
	@Column(name = "tar_pro_codigo")
	private String codigoProducto;
	
	@Column(name = "tar_num_cuenta")
	private String numCuenta;
	
	@Column(name = "tar_limite")
	private Integer limite;
	
	@Column(name = "tar_disponible")
	private Double disponible;
	
	@Column(name = "tar_tasa_interes")
	private Double tasaInteres;
	
	@Column(name = "tar_intereses_acumulados")
	private Double interesAcumulado;
	
	@Column(name = "tar_fecha_corte")
	private String fechaCorte;
}
