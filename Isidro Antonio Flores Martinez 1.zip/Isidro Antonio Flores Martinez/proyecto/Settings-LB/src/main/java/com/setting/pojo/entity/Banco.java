package com.setting.pojo.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity(name = "bnc_banco")
@Data
public class Banco {
	@Id
	@Column(name = "bnc_codigo")		
	private String codigo;		

	@Column(name = "bnc_nombre")
	private String nombre;
	
	@Column(name = "bnc_fecha_creacion")
	private Date fechaCreacion;
	
	@Column(name = "bnc_creado_por")
	private String creadoPor;
	
	@Column(name = "bnc_fecha_modificacion")
	private Date fechaModificacion;
	
	@Column(name = "bnc_modificado_por")
	private String modificadoPor;
	

}