package com.setting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.setting.pojo.response.WrapperResponse;
import com.setting.pojo.usuariocliente.request.UsuarioClienteRequest;
import com.setting.process.JsonProcess;

@RestController
@RequestMapping("/cliente")
public class ClienteController {
private JsonProcess proc;
	
	@Autowired
	public ClienteController(JsonProcess jsPro)
	{
		this.proc = jsPro;
	}
	
	@PostMapping("/agregar")
	public WrapperResponse<Boolean> Parameters (@RequestBody UsuarioClienteRequest request)
	{

			return proc.usuarioCliente(request); 
		
	}
}

