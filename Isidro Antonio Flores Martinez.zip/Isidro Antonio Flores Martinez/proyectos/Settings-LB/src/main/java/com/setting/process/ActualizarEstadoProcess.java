package com.setting.process;

import org.springframework.stereotype.Service;

import com.setting.pojo.entity.Usuario;
import com.setting.pojo.usuario.ActualizarEstadoRequest;
import com.setting.repository.UsuarioRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ActualizarEstadoProcess {

	private UsuarioRepository usuarioRepository;
	
	public ActualizarEstadoProcess(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;
	}
	
	public Usuario actualizarEstado(ActualizarEstadoRequest request){
		Integer numero;
		Usuario usuario;
		try {
			usuario = new Usuario();
			numero = null;
			
			numero = usuarioRepository.ActualizarEstado(request.getUsuario(), request.getEstado());
			
			if(numero == 1) {
				usuario = usuarioRepository.obtenerUsuarioporID(request.getUsuario());
			}else {
				usuario = null;
			}
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			usuario = null;
		}
		
		return usuario;
	}
}
